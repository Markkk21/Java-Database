/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package beta11;

import java.awt.Image;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Mark Garcia
 */
public class add_product extends javax.swing.JFrame {

    public add_product() {
        initComponents();
        
        fillTable();
        

    }

    String photopath=""; 
    
    public ImageIcon resizeImage(String photopath,byte[] photo){
        
       ImageIcon myPhoto=null;  
       if (photopath!=null) 
       {
       myPhoto=new ImageIcon(photopath);
       }
       else
       {
       myPhoto=new ImageIcon(photo);     
       }
       Image img=myPhoto.getImage();
       Image img1=img.getScaledInstance(photo1.getWidth(),photo1.getHeight(),Image.SCALE_SMOOTH);
       ImageIcon ph=new ImageIcon(img1);
       return ph;       
      
    }
    public ArrayList<productlist> retrieveData(){
        PreparedStatement ps;
        ResultSet rs;
        ArrayList<productlist> al=null;
                al=new ArrayList<productlist>();
       
        try {
        MYCONNECTION myconnection= new MYCONNECTION();
        String selectQuery="select * from tblproduct";
        ps = myconnection.createConnection().prepareStatement(selectQuery);
        rs= ps.executeQuery();
        
       productlist product;
            while (rs.next()) 
                {
                product = new productlist(rs.getInt(1),rs.getString(2),
                rs.getString(3),rs.getString(4),              
                rs.getBytes("photo"));                
                al.add(product);
                }
            } 
        
        catch (Exception e) 
            {
            System.out.println(e);
            }
            return al; 
      
}
    public void fillTable(){
        ArrayList<productlist> al=retrieveData();
        DefaultTableModel model=(DefaultTableModel)table.getModel();
        model.setRowCount(0); 
        Object[] row=new Object[5];
        for (int i = 0; i < al.size(); i++) {
        row[0]=al.get(i).getId();
        row[1]=al.get(i).getName();
        row[2]=al.get(i).getQuantity();
        row[3]=al.get(i).getPrice();  
        row[4]=al.get(i).getPhoto();
      
        model.addRow(row);
        }
    }
    public void showItemToFields(int index){
        txtfieldid.setText(Integer.toString(retrieveData().get(index).getId()));
        txtfieldname.setText(retrieveData().get(index).getName());
        txtfieldquantity.setText(retrieveData().get(index).getQuantity());
        txtfieldprice.setText(retrieveData().get(index).getPrice());
        
        try{}
        catch (Exception e)
        {
        System.out.println("Error at showItemToFields method "+e);
        }
        
        
        photo1.setIcon(resizeImage(null, retrieveData().get(index).getPhoto()));  

}




    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        labelid = new javax.swing.JLabel();
        labelname = new javax.swing.JLabel();
        labelquantity = new javax.swing.JLabel();
        labelprice = new javax.swing.JLabel();
        labelsearch = new javax.swing.JLabel();
        txtfieldid = new javax.swing.JTextField();
        txtfieldname = new javax.swing.JTextField();
        txtfieldquantity = new javax.swing.JTextField();
        txtfieldprice = new javax.swing.JTextField();
        txtfieldsearch = new javax.swing.JTextField();
        addbutton = new javax.swing.JButton();
        uploadbutton = new javax.swing.JButton();
        addtable = new javax.swing.JScrollPane();
        table = new javax.swing.JTable();
        photo1 = new javax.swing.JLabel();
        bgadd = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setResizable(false);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        labelid.setFont(new java.awt.Font("Miriam", 1, 18)); // NOI18N
        labelid.setForeground(new java.awt.Color(255, 255, 255));
        labelid.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        labelid.setText("ID:");
        getContentPane().add(labelid, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 30, 80, 30));

        labelname.setFont(new java.awt.Font("Miriam", 1, 18)); // NOI18N
        labelname.setForeground(new java.awt.Color(255, 255, 255));
        labelname.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        labelname.setText("Name:");
        getContentPane().add(labelname, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 70, 80, 30));

        labelquantity.setFont(new java.awt.Font("Miriam", 1, 18)); // NOI18N
        labelquantity.setForeground(new java.awt.Color(255, 255, 255));
        labelquantity.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        labelquantity.setText("Quantity:");
        getContentPane().add(labelquantity, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 110, 80, 30));

        labelprice.setFont(new java.awt.Font("Miriam", 1, 18)); // NOI18N
        labelprice.setForeground(new java.awt.Color(255, 255, 255));
        labelprice.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        labelprice.setText("Price:");
        getContentPane().add(labelprice, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 150, 80, 30));

        labelsearch.setFont(new java.awt.Font("Miriam", 1, 18)); // NOI18N
        labelsearch.setForeground(new java.awt.Color(255, 255, 255));
        labelsearch.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        labelsearch.setText("SEARCH:");
        getContentPane().add(labelsearch, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 30, 90, 30));

        txtfieldid.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtfieldidActionPerformed(evt);
            }
        });
        getContentPane().add(txtfieldid, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 30, 190, 30));
        getContentPane().add(txtfieldname, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 70, 190, 30));
        getContentPane().add(txtfieldquantity, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 110, 190, 30));
        getContentPane().add(txtfieldprice, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 150, 190, 30));

        txtfieldsearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtfieldsearchActionPerformed(evt);
            }
        });
        txtfieldsearch.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtfieldsearchKeyReleased(evt);
            }
        });
        getContentPane().add(txtfieldsearch, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 30, 330, 30));

        addbutton.setBackground(new java.awt.Color(204, 204, 204));
        addbutton.setFont(new java.awt.Font("Miriam", 1, 14)); // NOI18N
        addbutton.setText("ADD PRODUCT");
        addbutton.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        addbutton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addbuttonActionPerformed(evt);
            }
        });
        getContentPane().add(addbutton, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 380, 150, 40));

        uploadbutton.setFont(new java.awt.Font("Miriam", 1, 12)); // NOI18N
        uploadbutton.setText("UPLOAD PHOTO");
        uploadbutton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                uploadbuttonActionPerformed(evt);
            }
        });
        getContentPane().add(uploadbutton, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 350, 130, 40));

        table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "ID", "Name", "Quantity", "Price"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        table.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tableMouseClicked(evt);
            }
        });
        addtable.setViewportView(table);

        getContentPane().add(addtable, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 70, 440, 280));

        photo1.setBackground(new java.awt.Color(255, 255, 255));
        photo1.setOpaque(true);
        getContentPane().add(photo1, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 190, 190, 140));

        bgadd.setIcon(new javax.swing.ImageIcon(getClass().getResource("/beta11/image/blackbg.jpg"))); // NOI18N
        getContentPane().add(bgadd, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 750, 440));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void addbuttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addbuttonActionPerformed

     PreparedStatement ps;
     ResultSet rs;
        
     String id=txtfieldid.getText();
     String name=txtfieldname.getText();
     String quantity=txtfieldquantity.getText();
     String price=txtfieldprice.getText();
     
     
    if (txtfieldid.getText().equals(""))
    {
    JOptionPane.showMessageDialog(null,"Input ID");
    }
    else if (id.equals(""))
    {
    JOptionPane.showMessageDialog(null,"Input Name");  
    }
    else if (name.equals(""))
    {
    JOptionPane.showMessageDialog(null,"Input Name");  
    }   
    else if (quantity.equals(""))
    {
    JOptionPane.showMessageDialog(null,"Input Quantity");  
    }
    else if (price.equals(""))
    {    
    JOptionPane.showMessageDialog(null,"Input Price"); 
    }
    else if (photo1.getIcon()==null)
    {
    JOptionPane.showMessageDialog(null,"Upload a Photo");  
    }     
    
    {
        
     try { 
         
        MYCONNECTION myconnection= new MYCONNECTION();
     
        String selectQuery="Insert into tblproduct (id,name,quantity,price,photo) values(?,?,?,?,?)";
       
        ps = myconnection.createConnection().prepareStatement(selectQuery);



        ps.setInt(1,Integer.parseInt(txtfieldid.getText()));
        ps.setString(2, name);
        ps.setString(3, quantity);
        ps.setString(4, price);
                
        InputStream is=new FileInputStream(new File(photopath));
        ps.setBlob(5,is);            
        
        int res=ps.executeUpdate();
        
        if (res>=1)
        {
        JOptionPane.showMessageDialog(null,res + " Product successfully added");
        
        txtfieldid.setText("");
        txtfieldname.setText("");
        txtfieldquantity.setText("");
        txtfieldprice.setText("");
        photo1.setIcon(null);
        
        txtfieldid.setEnabled(false);
        txtfieldname.setEnabled(false);
        txtfieldquantity.setEnabled(false);
        txtfieldprice.setEnabled(false);
        
        uploadbutton.setEnabled(false);
        addbutton.setEnabled(true);
        
        fillTable();
        
        }
        else
        {
        JOptionPane.showMessageDialog(null,"Transaction Failed...");     
        }
       
        
        
        
     }
     catch (Exception ex)
     {
     Logger.getLogger(frmlogin.class.getName()).log(Level.SEVERE, null, ex);
     }
    }                                       



    }//GEN-LAST:event_addbuttonActionPerformed

    private void uploadbuttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_uploadbuttonActionPerformed
    JFileChooser chooser=new JFileChooser();
    chooser.setCurrentDirectory(new File(System.getProperty("user.home")));
    FileNameExtensionFilter newf=new FileNameExtensionFilter("*.image", "jpg","png");   
    chooser.addChoosableFileFilter(newf);
    int ans=chooser.showSaveDialog(null);
    
    if (ans==JFileChooser.APPROVE_OPTION) {
        File selectedPhoto=chooser.getSelectedFile();
        String path=selectedPhoto.getAbsolutePath();
        photo1.setIcon(resizeImage(path,null));
        this.photopath=path;    
        }
    }//GEN-LAST:event_uploadbuttonActionPerformed

    private void txtfieldidActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtfieldidActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtfieldidActionPerformed

    private void tableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tableMouseClicked
    int productid=table.getSelectedRow();
        showItemToFields(productid);
        
        txtfieldname.setEnabled(true);
        txtfieldquantity.setEnabled(true);
        txtfieldprice.setEnabled(true);
       
        uploadbutton.setEnabled(true);
        addbutton.setEnabled(true);

    }//GEN-LAST:event_tableMouseClicked

    private void txtfieldsearchKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtfieldsearchKeyReleased
                PreparedStatement ps;
                ResultSet rs;  
        
                ArrayList<productlist> al=null;
                al=new ArrayList<productlist>();
                String val=txtfieldsearch.getText().toString();
            
       
       try {
                
            MYCONNECTION myconnection= new MYCONNECTION();
            String selectQuery="select * from tblproduct where id like '%"+val+"%'";
            ps = myconnection.createConnection().prepareStatement(selectQuery);
            rs= ps.executeQuery();
            
        
            productlist product;
            while (rs.next()) {
                product = new productlist(rs.getInt(1),rs.getString(2),
                rs.getString(3),rs.getString(4),
                rs.getBytes("photo"));                
                al.add(product);
              }
            
        DefaultTableModel model=(DefaultTableModel)table.getModel();
        model.setRowCount(0); 
        Object[] row=new Object[10];
        for (int i = 0; i < al.size(); i++) {
        row[0]=al.get(i).getId();
        row[1]=al.get(i).getName();
        row[2]=al.get(i).getQuantity();
        row[3]=al.get(i).getPrice();   
        row[4]=al.get(i).getPhoto();   
        model.addRow(row);
        }           
        } catch (Exception e) {
            System.out.println(e);
        }

    }//GEN-LAST:event_txtfieldsearchKeyReleased

    private void txtfieldsearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtfieldsearchActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtfieldsearchActionPerformed


    public static void main(String args[]) {


        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new add_product().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton addbutton;
    private javax.swing.JScrollPane addtable;
    private javax.swing.JLabel bgadd;
    private javax.swing.JLabel labelid;
    private javax.swing.JLabel labelname;
    private javax.swing.JLabel labelprice;
    private javax.swing.JLabel labelquantity;
    private javax.swing.JLabel labelsearch;
    private javax.swing.JLabel photo1;
    private javax.swing.JTable table;
    private javax.swing.JTextField txtfieldid;
    private javax.swing.JTextField txtfieldname;
    private javax.swing.JTextField txtfieldprice;
    private javax.swing.JTextField txtfieldquantity;
    private javax.swing.JTextField txtfieldsearch;
    private javax.swing.JButton uploadbutton;
    // End of variables declaration//GEN-END:variables
}
