/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package beta11;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFrame;
import javax.swing.JOptionPane;



public class frmregister extends javax.swing.JFrame {

 
    public frmregister() {
        initComponents();
    }
    
    
    public boolean verifyFields(){
    String username=txtname.getText();
    String pass1=String.valueOf(txtpassword.getPassword());
    String pass2=String.valueOf(txtpassword1.getPassword());
        
    if (username.trim().equals("") || pass1.trim().equals("") || pass2.trim().equals(""))
    {
        JOptionPane.showMessageDialog(null,"Empty Fields!");
        return false;          
    }
        
    else if(!pass1.equals(pass2))
    {    
        JOptionPane.showMessageDialog(null,"Confirm Password!");
        return false;          
    }
    else
    {
        return true;
    }
        
                
    }

    
    
    public boolean checkUsername(String username)
    {
        PreparedStatement ps;
        ResultSet rs;
        boolean username_exist=false;
        
        String query="Select * from `user` WHERE `username`=?";
        
        try
        {
            MYCONNECTION myconnection= new MYCONNECTION
            ps=MYCONNECTION,getConnection().prepareStatement(query);
            ps.setString(1, username);
            rs=ps.executeQuery();
            
            
            if(rs.next())
            {
                username_exist=true;
                JOptionPane.showMessageDialog(null,"Username already taken");
                
            }

        }
            catch (SQLException ex)
        {
            Logger.getLogger(frmregister.class.getName()).log(Level.SEVERE,null,ex);
        }
        
        return username_exist;
    }
            
            
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        pass = new javax.swing.JLabel();
        pass1 = new javax.swing.JLabel();
        user = new javax.swing.JLabel();
        txtname = new javax.swing.JTextField();
        txtpassword = new javax.swing.JPasswordField();
        txtpassword1 = new javax.swing.JPasswordField();
        logo = new javax.swing.JLabel();
        loginlabel = new javax.swing.JLabel();
        registerbutton = new javax.swing.JButton();
        loginbutton = new javax.swing.JButton();
        cancelbutton = new javax.swing.JButton();
        BGBGBGBNG = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(0, 0, 0));
        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 20, 20, 370));

        pass.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        pass.setText("Confirm Password:");
        getContentPane().add(pass, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 220, 120, -1));

        pass1.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        pass1.setText("Create Password:");
        getContentPane().add(pass1, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 170, 110, -1));

        user.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        user.setText("Username:");
        getContentPane().add(user, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 120, -1, -1));

        txtname.setBackground(new java.awt.Color(204, 204, 204));
        txtname.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtnameActionPerformed(evt);
            }
        });
        getContentPane().add(txtname, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 140, 190, 30));

        txtpassword.setBackground(new java.awt.Color(204, 204, 204));
        txtpassword.setFont(new java.awt.Font("OCR A Std", 1, 11)); // NOI18N
        txtpassword.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtpasswordActionPerformed(evt);
            }
        });
        getContentPane().add(txtpassword, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 190, 190, 30));

        txtpassword1.setBackground(new java.awt.Color(204, 204, 204));
        txtpassword1.setFont(new java.awt.Font("OCR A Std", 1, 11)); // NOI18N
        txtpassword1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtpassword1ActionPerformed(evt);
            }
        });
        getContentPane().add(txtpassword1, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 240, 190, 30));

        logo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/beta11/image/logo2.jpg"))); // NOI18N
        getContentPane().add(logo, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 70, 200, 240));

        loginlabel.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        loginlabel.setText("REGISTRATION");
        getContentPane().add(loginlabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 60, 160, 40));

        registerbutton.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        registerbutton.setText("REGISTER");
        registerbutton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                registerbuttonActionPerformed(evt);
            }
        });
        getContentPane().add(registerbutton, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 290, 90, -1));

        loginbutton.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        loginbutton.setText("LOGIN");
        loginbutton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                loginbuttonActionPerformed(evt);
            }
        });
        getContentPane().add(loginbutton, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 290, 90, -1));

        cancelbutton.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        cancelbutton.setText("CANCEL");
        cancelbutton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cancelbuttonActionPerformed(evt);
            }
        });
        getContentPane().add(cancelbutton, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 330, 90, -1));

        BGBGBGBNG.setIcon(new javax.swing.ImageIcon(getClass().getResource("/beta11/image/loginpage.jpg"))); // NOI18N
        getContentPane().add(BGBGBGBNG, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtnameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtnameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtnameActionPerformed

    private void txtpassword1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtpassword1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtpassword1ActionPerformed

    private void txtpasswordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtpasswordActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtpasswordActionPerformed

    private void loginbuttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_loginbuttonActionPerformed
               {
                    frmlogin loginpage=new frmlogin();
                    loginpage.setVisible(true);
                    loginpage.pack();
                    loginpage.setLocationRelativeTo(null);
                    loginpage.setExtendedState(JFrame.NORMAL);
                   
                } 
    }//GEN-LAST:event_loginbuttonActionPerformed

    private void cancelbuttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cancelbuttonActionPerformed
        {
                    
                    this.dispose();
                } 
    }//GEN-LAST:event_cancelbuttonActionPerformed

    private void registerbuttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_registerbuttonActionPerformed
    String username=txtname.getText();
    String pass1=String.valueOf(txtpassword.getPassword());
    String pass2=String.valueOf(txtpassword1.getPassword());
    }//GEN-LAST:event_registerbuttonActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(frmregister.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(frmregister.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(frmregister.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(frmregister.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new frmregister().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel BGBGBGBNG;
    private javax.swing.JButton cancelbutton;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JButton loginbutton;
    private javax.swing.JLabel loginlabel;
    private javax.swing.JLabel logo;
    private javax.swing.JLabel pass;
    private javax.swing.JLabel pass1;
    private javax.swing.JButton registerbutton;
    private javax.swing.JTextField txtname;
    private javax.swing.JPasswordField txtpassword;
    private javax.swing.JPasswordField txtpassword1;
    private javax.swing.JLabel user;
    // End of variables declaration//GEN-END:variables
}
